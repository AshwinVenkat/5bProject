package withEncryptionPiyush;

import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import javax.imageio.ImageIO;

public class imagerecieve {

    /**
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO Auto-generated method stub
        // 
        System.out.println("cnnection initiated");
        ServerSocket serverSocket = new ServerSocket(8129);
        while(true){
        Socket socket = serverSocket.accept();
        System.out.println("Accepted connection : " + socket);
        BufferedImage tmp = new BufferedImage(400, 400,BufferedImage.TYPE_INT_RGB);
        try {
            try {
                InputStream in = socket.getInputStream();
                tmp = ImageIO.read(in);
            } finally {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            // code to print the shell script values on console
            String appendIPAddress = socket.getInetAddress().toString().substring(1);
            String filename = "cloudletGroup5b_" + appendIPAddress;
            System.out.println( filename);
            ImageIO.write(tmp, "png", new File("/home/ruchika/" + filename));
            System.out.println("Image recieved successfully");
            String cmd = "/home/ruchika/tess/tesseract.sh /home/ruchika/"+ filename;
            ProcessBuilder pb = new ProcessBuilder("bash", "-c", cmd);
            pb.redirectErrorStream(true);
            Process shell = pb.start();
            InputStream shellIn = shell.getInputStream(); int shellExitStatus
            = shell.waitFor(); int c; while ((c = shellIn.read()) != -1)
            {System.out.write(c);} try {shellIn.close();} catch (IOException
            ignoreMe) {}
           
        }
        catch (Exception exp) {

        }
     }
    }
}
package withEncryptionPiyush;

import java.net.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.*;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;

public class MultipleRequest implements Runnable {

  private Socket connection;
  private String TimeStamp;
  private int ID;
  
  public static void main(String[] args) {
  int port = 8129;
  int count = 0;
    try{
      ServerSocket socket1 = new ServerSocket(port);
      System.out.println("MultipleSocketServer Initialized");
      while (true) {
        Socket connection = socket1.accept();
        Runnable runnable = new MultipleRequest(connection, ++count);
        Thread thread = new Thread(runnable);
        thread.start();
      }
    }
    catch (Exception e) {}
  }
MultipleRequest(Socket s, int i) {
  this.connection = s;
  this.ID = i;
}
@Override
public void run() {
	// TODO Auto-generated method stub
	BufferedImage tmp = new BufferedImage(400, 400,BufferedImage.TYPE_INT_RGB);
    try {
        try {
            InputStream in = connection.getInputStream();
            tmp = ImageIO.read(in);
        } finally {
            connection.close();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }

    try {
        // code to print the shell script values on console
        String appendIPAddress = connection.getInetAddress().toString().substring(1);
        String filename = "cloudletGroup5b_" + appendIPAddress + ".jpg";
        System.out.println( filename);
        ImageIO.write(tmp, "png", new File("D:\\" + filename));
        System.out.println("Image recieved successfully");
        /*String cmd = "/home/ruchika/tess/tesseract.sh /home/ruchika/"+ filename;
        ProcessBuilder pb = new ProcessBuilder("bash", "-c", cmd);
        pb.redirectErrorStream(true);
        Process shell = pb.start();
        InputStream shellIn = shell.getInputStream(); int shellExitStatus
        = shell.waitFor(); int c; while ((c = shellIn.read()) != -1)
        {System.out.write(c);} try {shellIn.close();} catch (IOException
        ignoreMe) {}*/
       
    }
    catch (Exception exp) {

    }
}

}

package withEncryptionPiyush;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import withEncryptionPiyush.sendModel;

public class imagesend{

	/**
	 * @param args
	 * @throws IOException 
	 * @throws UnknownHostException 
	 * @throws NoSuchPaddingException 
	 * @throws NoSuchAlgorithmException 
	 * @throws InvalidAlgorithmParameterException 
	 * @throws InvalidKeyException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 */
	public static void mainImageSend(String filename) throws UnknownHostException, IOException, InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		// TODO Auto-generated method stub
		long startTime = System.currentTimeMillis();
		Cipher c = Cipher.getInstance("AES");
		Socket socket = new Socket("192.168.12.119", 8229);  // server ip address and socket
		File transferFile = new File (filename); // location of the file to be sent
        byte [] bytearray  = new byte [(int)transferFile.length()]; 
        FileInputStream fin = new FileInputStream(transferFile);
        BufferedInputStream bin = new BufferedInputStream(fin);
        bin.read(bytearray,0,bytearray.length);
        String key1 = "1234567812345678";
		byte[] key2 = key1.getBytes();
		SecretKeySpec secret = new SecretKeySpec(key2, "AES");
		c.init(Cipher.ENCRYPT_MODE, secret);
        OutputStream os = (OutputStream) socket.getOutputStream();
        System.out.println("Sending Files...");
        // bytearray is to be encrypted here and then should be sent
        os.write(bytearray,0,bytearray.length);
        os.flush();
        bin.close();
        socket.close();
        System.out.println("File transfer complete");
        textrecieve(); // calling the function that now behave as server and ready to recieve the converted text file
        long endTime = System.currentTimeMillis();
        long totalTime = endTime - startTime;
        System.out.println("File recieved successfully");
        System.out.println("Time taken : "+totalTime);
	}
	
	
	@SuppressWarnings("null")
	public static void textrecieve() throws IOException{
		//int filesize=2022386;
	    //int bytesRead;
	    //int currentTot = 0;
	   // byte [] bytearray  = new byte [filesize];
	    System.out.println("started");
		ServerSocket serverSocket = new ServerSocket(8589);
		//System.out.println("server socket made" + serverSocket);
		Socket socket = serverSocket.accept();
		System.out.println("Accepted connection : " + socket);
		try {
			try {
				BufferedOutputStream bos = null;
				//byte[] iv = null;
				//KeyGenerator kg = KeyGenerator.getInstance("DES");
				Cipher c = Cipher.getInstance("AES");
				//SecretKey key = kg.generateKey();
				String key1 = "1234567812345678";
				byte[] key2 = key1.getBytes("UTF-8");
				SecretKeySpec secret = new SecretKeySpec(key2, "AES");
				sendModel rtemp = new sendModel();
				InputStream in = socket.getInputStream();
				ObjectInputStream ois = new ObjectInputStream(in);
				rtemp = (sendModel) ois.readObject();
				//System.out.println(rtemp.getStr());
				FileOutputStream fos = new FileOutputStream("D:\\copy.txt");
		        bos = new BufferedOutputStream(fos);
		        FileOutputStream fosundec = new FileOutputStream("D:\\copyundec.txt");
		        BufferedOutputStream bosundec = new BufferedOutputStream(fosundec);
		        bosundec.write(rtemp.getData().toString().getBytes());
		        bosundec.close();
		        //IvParameterSpec dps = new IvParameterSpec(rtemp.getKey());
		        //System.out.println("block size "+c.getBlockSize());
				c.init(Cipher.DECRYPT_MODE, secret);
				//System.out.println(rtemp.getData().toString());
				byte[] encBytes = new sun.misc.BASE64Decoder().decodeBuffer(rtemp.getData());  
	            byte[] plainTxtBytes = c.doFinal(encBytes);
	            String sttemp = new String(plainTxtBytes);
	            System.out.println("The recieved text is : ");
	            System.out.println(sttemp);
		        bos.write(sttemp.getBytes());
		        in.close();
		        bos.flush();
		        bos.close();
		        socket.close();
			} catch (InvalidKeyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalBlockSizeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (BadPaddingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchPaddingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				socket.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

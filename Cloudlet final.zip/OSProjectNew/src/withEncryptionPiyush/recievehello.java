package withEncryptionPiyush;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;


public class recievehello {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String sttemp = null;
		try {
			// TODO Auto-generated method stub
			ServerSocket serverSocket = new ServerSocket(8489);
			Socket socket = serverSocket.accept();
			System.out.println("Accepted connection : " + socket);
			Cipher c = Cipher.getInstance("AES");
			//SecretKey key = kg.generateKey();
			String key1 = "1826402937486292";
			byte[] key2 = key1.getBytes();
			SecretKeySpec secret = new SecretKeySpec(key2, "AES");
			InputStream in = socket.getInputStream();
			InputStreamReader is = new InputStreamReader(in);
			StringBuilder sb=new StringBuilder();
			BufferedReader br = new BufferedReader(is);
			String read = br.readLine();
			while(read != null) {
				//System.out.println(read);
				sb.append(read);
				read =br.readLine();

			}
			//BufferedInputStream bos = new BufferedInputStream(in);
			System.out.println(sb.toString());
			c.init(Cipher.DECRYPT_MODE, secret);
			//System.out.println(rtemp.getData().toString());
			byte[] encBytes;

			//encBytes = new sun.misc.BASE64Decoder().decodeBuffer(sb.toString());

			byte[] plainTxtBytes = c.doFinal(sb.toString().getBytes());
			sttemp = new String(plainTxtBytes);
			System.out.println("The recieved text is : ");
			System.out.println(sttemp);


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  

		System.out.println(sttemp);

	}
}

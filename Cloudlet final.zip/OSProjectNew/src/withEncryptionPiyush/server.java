package withEncryptionPiyush;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class server {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sendModel smm = new sendModel();
		try {

			System.out.println("client initiated");
			//while(true){

			//KeyGenerator kg = KeyGenerator.getInstance("DES");
			Cipher c = Cipher.getInstance("AES");
			//Cipher c = Cipher.getInstance("AES");
			//SecretKey key = kg.generateKey();
			
			String key1 = "1234567812345678";
			byte[] key2 = key1.getBytes();
			smm.setKey(key2);
			SecretKeySpec secret = new SecretKeySpec(key2, "AES");

			File transferFile = new File ("D:\\copy.txt");
			int length = (int)transferFile.length();
			System.out.println("------------\n"+length+"\n---------------");
			byte [] bytearray  = new byte [(int)transferFile.length()];
			System.out.println("-->"+bytearray);
			FileInputStream fin = new FileInputStream(transferFile);
			BufferedInputStream bin = new BufferedInputStream(fin);
			bin.read(bytearray,0,bytearray.length);

			//c.init(Cipher.ENCRYPT_MODE, key2);
			c.init(Cipher.ENCRYPT_MODE, secret);
			byte[] encrypted = c.doFinal(bytearray);

			String tosend = new sun.misc.BASE64Encoder().encode(encrypted);

//			byte[] newEncrypted = tosend.getBytes();

			/*int i=0;
			for(i=0;i<encrypted.length-1;i++){
				newEncrypted[i] = encrypted[i];
			}*/
			/*newEncrypted[i] = 0000*/;

			//System.out.println(newEncrypted.length);
			byte[] iv = c.getIV();
			//System.out.println(iv);

			Socket s = new Socket("192.16.13.27",8489);  
			System.out.println("Accepted connection : " + s);	
			OutputStream os = s.getOutputStream();  
			ObjectOutputStream oos1 = new ObjectOutputStream(os);  
			//ObjectOutputStream oos2 = new ObjectOutputStream(os);  
			
			smm.setData(tosend);
			//System.out.println("Data = "+smm.getData().toString());
			//smm.setKey(iv);
			//System.out.println("key = "+smm.getKey().toString());
			try{
				oos1.writeObject(smm);
				
			}catch(Exception e){
				e.printStackTrace();
			}

			oos1.close();  
			os.close();  
			bin.close();
			s.close();
			System.out.println("File transfer complete");

			/*Socket socket = new Socket("192.168.12.95",8289);
			System.out.println("Accepted connection : " + socket);
			File transferFile = new File ("/home/ashwin/rahul.txt");
			byte [] bytearray  = new byte [(int)transferFile.length()];
			FileInputStream fin = new FileInputStream(transferFile);
			BufferedInputStream bin = new BufferedInputStream(fin);

			bin.read(bytearray,0,bytearray.length);

			c.init(Cipher.ENCRYPT_MODE, key);
			byte encrypted[] = c.doFinal(bytearray);
			sm.data = encrypted;
			byte iv[] = c.getIV();
			sm.key = iv;

			byte[] temp = convert(sm);

			BigInteger plaintext = new BigInteger(bytearray);
      		RSA key = new RSA(50);
      		BigInteger encrypt = key.encrypt(plaintext);

			OutputStream os = (OutputStream) socket.getOutputStream();

			System.out.println("Sending Files...");

			os.write(temp);
			//os.flush();
			//oos.close();
			os.close();

			os = socket.getOutputStream();
			os.write(encrypted);
			os.flush();
			 */
		} catch (IOException e) {

			e.printStackTrace();
		} catch (InvalidKeyException e) {

			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {

			e.printStackTrace();
		} catch (BadPaddingException e) {

			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {

			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		}
	}

}




/*try {
			System.out.println("client initiated");
			//while(true){
			Socket socket;

			socket = new Socket("192.168.12.95",8289);

			System.out.println("Accepted connection : " + socket);
			File transferFile = new File ("/home/ashwin/rahul.txt");
			byte [] bytearray  = new byte [(int)transferFile.length()];
			FileInputStream fin = new FileInputStream(transferFile);
			BufferedInputStream bin = new BufferedInputStream(fin);
			bin.read(bytearray,0,bytearray.length);
			String str = new String(bytearray);
			System.out.println("--------bin---------\n"+str+"\n-----------------");
			BigInteger plaintext = new BigInteger(bytearray);
			System.out.println("---------plain text-------\n"+plaintext+"\n------------------");
			RSA key = new RSA(50);
			BigInteger encrypt = key.encrypt(plaintext);

			System.out.println("------------------encrypted data------------------");
			System.out.println(encrypt);
			System.out.println(encrypt.toByteArray());
			String str2 = new String(encrypt.toByteArray());
			System.out.println(str2);
			System.out.println("--------------------------------------------------");


			BigInteger decrypt = key.decrypt(encrypt);
			System.out.println("------------------decrypted data------------------");
			System.out.println(decrypt);
			System.out.println(decrypt.toByteArray());
			String str3 = new String(decrypt.toByteArray());
			System.out.println(str3);
			System.out.println("--------------------------------------------------");

			System.out.println();
			OutputStream os = (OutputStream) socket.getOutputStream();
			String str4 = new String(os.toString());
			System.out.println("output stream = "+str4);
			System.out.println("Sending Files...");
			os.write(encrypt.toByteArray());
			os.flush();
			bin.close();
			socket.close();
			System.out.println("File transfer complete");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
 */







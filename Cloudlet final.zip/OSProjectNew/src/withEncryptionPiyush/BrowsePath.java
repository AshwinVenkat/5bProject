package withEncryptionPiyush;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.UnknownHostException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class BrowsePath extends JFrame implements ActionListener {

	JButton button;
	JTextField field;

	public BrowsePath() {
		this.setLayout(null);

		button = new JButton("browse");
		field = new JTextField();

		field.setBounds(30, 50, 200, 25);
		button.setBounds(240, 50, 100, 25);
		this.add(field);
		this.add(button);

		button.addActionListener(this);
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
	}

	public void actionPerformed(ActionEvent e) {
		Chooser frame = new Chooser();
		field.setText(frame.fileName);
		JOptionPane.showMessageDialog ( null,"The Image " + frame.fileName + "is now sent to cloudlet for conversion..!!");
		try {
			imagesend.mainImageSend(frame.fileName);
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InvalidKeyException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InvalidAlgorithmParameterException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NoSuchPaddingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalBlockSizeException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (BadPaddingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.exit(0);
	}

	public static void main(String args[]) {

		BrowsePath frame = new BrowsePath();
		frame.setSize(400, 180);
		frame.setLocation(200, 100);
		frame.setVisible(true);

	}
}

class Chooser extends JFrame {

	JFileChooser chooser;
	String fileName;

	public Chooser() {
		chooser = new JFileChooser();
		int r = chooser.showOpenDialog(new JFrame());
		if (r == JFileChooser.APPROVE_OPTION) {
			fileName = chooser.getSelectedFile().getPath();
		}
	}
}
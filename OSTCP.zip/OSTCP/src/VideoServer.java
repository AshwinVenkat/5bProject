    import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;

import javax.swing.JFrame;
import java.net.*;
import javax.imageio.*;
import java.util.*;
import java.io.*;
    public class VideoServer extends JFrame
    {
    BufferedImage img;
    Robot robot;
    Rectangle rect;
    public static void main(String args[]) throws IOException
    {
    	System.out.println("initiating connection");
   new VideoServer();
    }
    public VideoServer()
    {
    //init components
    try
    {
    robot = new Robot();
    rect = new Rectangle(200,200,300,300);
    }
    catch (AWTException e)
    {
    e.printStackTrace();
    }
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(500,500);
    // this.setVisible(true);
    takeShots();
    }
    private void takeShots()
    {
    try
    {
    ServerSocket s=new ServerSocket(8189);
    Socket incoming=s.accept();
    System.out.println("Accepted connection : " + incoming);
    try
    {
    OutputStream os=incoming.getOutputStream();
    for (int i = 0;i<100 ; i++)
    {
//    	Image image = Toolkit.getDefaultToolkit().getImage("/home/ruchika/eurotext.png");
//    	BufferedImage bImage = new BufferedImage(image.getWidth(null),
//                image.getHeight(null),
//                BufferedImage.TYPE_INT_ARGB);
//    	Graphics2D bImageGraphics = bImage.createGraphics();
//    	bImageGraphics.drawImage(image, null, null);
//    	RenderedImage img = (RenderedImage)bImage;
//    	System.out.println(img.getHeight()+"  "+img.getWidth());
    	File fnew = new File("/home/ruchika/SaraswatMa.jpg");
    	System.out.println(fnew.getTotalSpace());
    	BufferedImage bi = ImageIO.read(fnew);
    	System.out.println(bi);
    	//ByteArrayOutputStream bos = new ByteArrayOutputStream();
    	//System.out.println(new File("output.png"));
    	//ImageIO.write(bi,"png",new File("/home/ruchika/output.jpg"));
    //img = robot.createScreenCapture(rect);
    System.out.println(img);
    //repaint();
    ImageIO.write(bi,"jpg",os);
    if(img==null)
    System.out.println("NULL");
    try
    {
    Thread.sleep(50);
    }
    catch (InterruptedException e)
    {
    e.printStackTrace();
    }
    }
    }
    finally
    {
    s.close();
    }
    }
    catch(IOException e1)
    {
    }
    }
    /* public void paintComponent(Graphics g)
    {
    super.paintComponents(g);
    //Graphics2D g2 = (Graphics2D)g;
    //g2.drawImage(img,0,0,this);
    }*/
    }
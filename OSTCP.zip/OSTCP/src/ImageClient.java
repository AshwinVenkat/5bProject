    import java.util.*;
    import java.io.*;
    import java.net.*;
    import java.awt.image.*;
    import javax.imageio.*;
    public class ImageClient
    {
    public static void main(String args[])
    {
    ArrayList list=new ArrayList(100);
    BufferedImage tmp=new BufferedImage(400,400,BufferedImage.TYPE_INT_RGB);
    try
    {
    Socket s=new Socket("127.0.0.1",8189);
    try
    {
    InputStream in=s.getInputStream();
    for(int i=0;i<100;i++)
    {
    tmp=ImageIO.read(in);
    list.add(tmp);
    }
    }
    finally
    {
    s.close();
    }
    }
    catch(IOException e)
    {
    e.printStackTrace();
    }
    try
    {
    for(int i=0;i<100;i++)
    {
    tmp=(BufferedImage)list.get(i);
    ImageIO.write(tmp,"png",new File("/home/ruchika/OS"+i+".png"));
    }
    }
    catch(Exception exp)
    {
    System.out.println("hello5");
    }
    }
    }
package withEncryptionPiyush;

import java.io.Serializable;

public class ReturnText implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String str;
	
	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}
		
}

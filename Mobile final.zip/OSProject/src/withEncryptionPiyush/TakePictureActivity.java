package withEncryptionPiyush;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.osproject.R;

public class TakePictureActivity extends Activity {

	private static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 100;
	public static final int MEDIA_TYPE_IMAGE = 1;
	private Uri fileUri;
	static File mediaFile;
	TextView tv;
	Button save;
	String convertedText;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_take_picture);
		tv = (TextView)findViewById(R.id.displayText);	
		Intent intent = getIntent();
	}


	public void clickSaveButton(View view){


		setContentView(R.layout.activity_take_picture);

		convertedText = tv.getText().toString(); 

		try{

			File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "/OS-Project/Converted_Text.txt");

			BufferedWriter writer = new BufferedWriter(new FileWriter(file,true));

			writer.write(" ");
			writer.newLine();
			writer.flush();
			writer.close();
		}

		catch (IOException e) {
			e.printStackTrace();
		}

	}


	public void dispatchTakePictureIntent(View view){

		setContentView(R.layout.activity_take_picture);

		// create Intent to take a picture and return control to the calling application
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE); // create a file to save the image
		intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri); // set the image file name

		// start the image capture Intent
		startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);

	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE) {
			if (resultCode == RESULT_OK) {
				Toast.makeText(this, "Capture successful", Toast.LENGTH_LONG).show();


				Send send = new Send(this);
				send.execute();

				/*Recieve rec = new Recieve(this);
				rec.execute();*/

			} else if (resultCode == RESULT_CANCELED) {
				// User cancelled the image capture
				Toast.makeText(this, "User Cancelled the image capture",Toast.LENGTH_SHORT).show();
			} else {
				// Image capture failed, advise user
				Toast.makeText(this, "Image capture failed",Toast.LENGTH_SHORT).show();
			}
		}



	}

	private static Uri getOutputMediaFileUri(int type){
		return Uri.fromFile(getOutputMediaFile(type));
	}

	/** Create a File for saving an image or video */
	private static File getOutputMediaFile(int type){
		// To be safe, you should check that the SDCard is mounted
		// using Environment.getExternalStorageState() before doing this.

		File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
				Environment.DIRECTORY_PICTURES), "OS-Project");
		// This location works best if you want the created images to be shared
		// between applications and persist after your app has been uninstalled.

		// Create the storage directory if it does not exist
		if (! mediaStorageDir.exists()){
			if (! mediaStorageDir.mkdirs()){
				Log.d("OS-Project", "failed to create directory");
				return null;
			}
		}

		// Create a media file name
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

		if (type == MEDIA_TYPE_IMAGE){
			/*mediaFile = new File(mediaStorageDir.getPath() + File.separator +
					"IMG_"+ timeStamp + ".jpg");*/

			mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_1.png");
			System.out.println("----------------------------------mediaFile--------------------------------------------------------------"+mediaFile);
		} else {
			return null;
		}

		return mediaFile;
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_take_picture, menu);
		return true;
	}

}

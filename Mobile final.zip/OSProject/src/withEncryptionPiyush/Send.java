package withEncryptionPiyush;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import android.os.AsyncTask;
import android.widget.TextView;
import android.widget.Toast;

import com.example.osproject.R;

public class Send extends AsyncTask<String, String, String>{

	TextView tv = null;
	private TakePictureActivity takePictureActivityContext = null;
	String fileName;

	public Send(TakePictureActivity context) {
		takePictureActivityContext = context;
	}

	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub

		try {
			Socket socket = null;

			long startTime = System.currentTimeMillis();
			Cipher c = Cipher.getInstance("AES");

			socket = new Socket("192.168.12.119", 8289);

			File transferFile = new File (fileName); // location of the file to be sent
			byte [] bytearray  = new byte [(int)transferFile.length()]; 
			FileInputStream fin = new FileInputStream(transferFile);
			BufferedInputStream bin = new BufferedInputStream(fin);
			bin.read(bytearray,0,bytearray.length);
			KeyGenerator kg = KeyGenerator.getInstance("AES");
			String key1 = "1234567812345678";
			byte[] key2 = key1.getBytes();
			SecretKeySpec secret = new SecretKeySpec(key2, "AES");
			c.init(Cipher.ENCRYPT_MODE, secret);
			OutputStream os = (OutputStream) socket.getOutputStream();
			System.out.println("Sending Files...");
			// bytearray is to be encrypted here and then should be sent
			os.write(bytearray,0,bytearray.length);
			os.flush();
			bin.close();
			socket.close();
			System.out.println("File transfer complete");
			//textrecieve(); // calling the function that now behave as server and ready to recieve the converted text file
			long endTime = System.currentTimeMillis();
			long totalTime = endTime - startTime;
			System.out.println("File recieved successfully");
			System.out.println("Time taken : "+totalTime);

			/*try {
			try {

				// send start---------------------------------------------------------------------------------------------------------------------------------------------------------
				socket = new Socket("192.168.12.119", 8229);

				File transferFile = new File (Environment.getExternalStorageDirectory().getAbsolutePath()+"/Pictures/OS-Project/IMG_1.png"); // location of the file to be sent
				byte [] bytearray  = new byte [(int)transferFile.length()]; 
				FileInputStream fin = new FileInputStream(transferFile);
				BufferedInputStream bin = new BufferedInputStream(fin);
				bin.read(bytearray,0,bytearray.length);

				OutputStream os = (OutputStream) socket.getOutputStream();
				System.out.println("Sending Files...");


				os.write(bytearray,0,bytearray.length);
				os.flush();
				bin.close();
				socket.close();
				System.out.println("File transfer complete");

				// send end---------------------------------------------------------------------------------------------------------------------------------------------------------


				Recieve rec = new Recieve(takePictureActivityContext);
				rec.execute();


				System.out.println("File recieved successfully");


			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				socket.close();
			} 
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String result = "Image sent.. waiting for response!";
		return result;*/
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  // server ip address and socket
		catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return fileName;
	}

	protected void onPostExecute(String result) {

		Toast.makeText(takePictureActivityContext, "in ON_POST_EXECUTE_Send", Toast.LENGTH_SHORT).show();
		tv = (TextView) takePictureActivityContext.findViewById(R.id.displayText);
		tv.setText(result);
	}
}
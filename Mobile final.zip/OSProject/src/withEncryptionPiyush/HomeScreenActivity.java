package withEncryptionPiyush;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import com.example.connection.imagesend;
import com.example.osproject.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Toast;

public class HomeScreenActivity extends Activity {

	protected static final Object SERVICE_TYPE = null;
	protected static final String TAG = null;
	
	//imagesend is = new imagesend();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home_screen);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_home_screen, menu);
		return true;
	}

	public void NextPage(View view){
		//is.imageSend();
		Intent intent = new Intent(this, TakePictureActivity.class);
		startActivity(intent);
	}
	
	
}

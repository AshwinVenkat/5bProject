package withEncryptionPiyush;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import android.os.AsyncTask;
import android.os.Environment;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import com.example.osproject.R;

public class Recieve extends AsyncTask<String, Void, String> {

	TextView tv = null;
	private TakePictureActivity takePictureActivityContext = null;

	public Recieve(TakePictureActivity context) {
		takePictureActivityContext = context;
	}



	protected String doInBackground(String... arg0) {

		sendModel rtemp = null;
		Socket socket = null;
		ServerSocket serverSocket;
		 System.out.println("started");


			try {
				try {
					serverSocket = new ServerSocket(8489);
					socket = serverSocket.accept();
					System.out.println("Accepted connection : " + socket);
					BufferedOutputStream bos = null;
					//byte[] iv = null;
					//KeyGenerator kg = KeyGenerator.getInstance("DES");
					Cipher c = Cipher.getInstance("AES");
					//SecretKey key = kg.generateKey();
					String key1 = "1234567812345678";
					byte[] key2 = key1.getBytes("UTF-8");
					SecretKeySpec secret = new SecretKeySpec(key2, "AES");
					rtemp = new sendModel();
					InputStream in = socket.getInputStream();
					ObjectInputStream ois = new ObjectInputStream(in);
					rtemp = (sendModel) ois.readObject();
					System.out.println(rtemp.getStr());
					FileOutputStream fos = new FileOutputStream(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
			        bos = new BufferedOutputStream(fos);
			        FileOutputStream fosundec = new FileOutputStream(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
			        BufferedOutputStream bosundec = new BufferedOutputStream(fosundec);
			        bosundec.write(rtemp.getData().toString().getBytes());
			        bosundec.close();
			        IvParameterSpec dps = new IvParameterSpec(rtemp.getKey());
			        System.out.println("block size "+c.getBlockSize());
					c.init(Cipher.DECRYPT_MODE, secret);
					System.out.println(rtemp.getData().toString());
					byte[] encBytes = new sun.misc.BASE64Decoder().decodeBuffer(rtemp.getData());  
		            byte[] plainTxtBytes = c.doFinal(encBytes);
		            String sttemp = new String(plainTxtBytes);
		            System.out.println("The recieved text is : ");
		            System.out.println(sttemp);
			        bos.write(sttemp.getBytes());
			        in.close();
			        bos.flush();
			        bos.close();
			        socket.close();
				} catch (InvalidKeyException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalBlockSizeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (BadPaddingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NoSuchAlgorithmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NoSuchPaddingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {

					e.printStackTrace();
				} finally {
					socket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			String result = String.valueOf(rtemp.getData());
			return result;


		/*-------------------------new code added here !!-------------------------*/
		/*String read = null;
		StringBuilder sb = null;
		ServerSocket serverSocket;
		try {
			serverSocket = new ServerSocket(8589);

			Socket socket = serverSocket.accept();
			System.out.println("Accepted connection : " + socket);
			InputStream in = socket.getInputStream();
			InputStreamReader is = new InputStreamReader(in);
			sb=new StringBuilder();
			BufferedReader br = new BufferedReader(is);
			read = br.readLine();

			while(read != null) {

				sb.append(read);
				read =br.readLine();
			}

			System.out.println(sb.toString());
		} catch (IOException e) {

			e.printStackTrace();
		}
		return sb.toString();
*/
	}		 

	protected void onPostExecute(String result) {

		//Toast.makeText(takePictureActivityContext, "in ON_POST_EXECUTE_Recieve", Toast.LENGTH_SHORT).show();
		//Toast.makeText(takePictureActivityContext, "result = "+result, Toast.LENGTH_SHORT).show();
		tv = (TextView) takePictureActivityContext.findViewById(R.id.displayText);
		tv.setMovementMethod(new ScrollingMovementMethod());

		tv.setText(result);
		String convertedText = tv.getText().toString(); 
		
		try{
			int counter = result.getBytes().length;
			File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "/OS-Project/Converted_Text"+counter+".txt");

			BufferedWriter writer = new BufferedWriter(new FileWriter(file,true));

			writer.write(convertedText);
			writer.newLine();
			writer.flush();
			writer.close();
		}

		catch (IOException e) {
			e.printStackTrace();
		}

	}
}
package withEncryptionPiyush;

import java.io.Serializable;

public class sendModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String str;
	byte [] key;
	String data;

	public byte[] getKey() {
		return key;
	}
	public void setKey(byte[] key) {
		this.key = key;
	}
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
}

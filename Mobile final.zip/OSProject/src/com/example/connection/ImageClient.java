package com.example.connection;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.ArrayList;

import javax.imageio.ImageIO;
public class ImageClient
{
	public static void main(String args[])
	{
		ArrayList list=new ArrayList(100);
		BufferedImage tmp=new BufferedImage(400,400,BufferedImage.TYPE_INT_RGB);
		try
		{
			Socket s=new Socket("192.168.12.200",8189);
			try
			{
				InputStream in=s.getInputStream();
				for(int i=0;i<100;i++)
				{
					tmp=ImageIO.read(in);
					list.add(tmp);
				}
			}
			finally
			{
				s.close();
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		try
		{
			for(int i=0;i<100;i++)
			{
				tmp=(BufferedImage)list.get(i);
				ImageIO.write(tmp,"png",new File("OS"+i+".jpg"));
			}
		}
		catch(Exception exp)
		{
			System.out.println("hello5");
		}
	}
}
package com.example.connection;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class imagesend {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws UnknownHostException 
	 */
	public int imageSend() {
		// TODO Auto-generated method stub
		Socket socket;
		try {
			
			socket = new Socket("192.168.12.119", 8189);
			File transferFile = new File ("D:\\OSsend\\testos.jpg");
			byte [] bytearray  = new byte [(int)transferFile.length()];
			FileInputStream fin = new FileInputStream(transferFile);
			BufferedInputStream bin = new BufferedInputStream(fin);
			bin.read(bytearray,0,bytearray.length);
			OutputStream os = (OutputStream) socket.getOutputStream();
			//System.out.println("Sending Files...");
			os.write(bytearray,0,bytearray.length);
			os.flush();
			socket.close();
			// System.out.println("File transfer complete");
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return 1;
	}
}